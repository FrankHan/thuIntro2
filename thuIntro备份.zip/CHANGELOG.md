# Changelog

### v0.9.2

* New flags for SVG-related capabilities: `svg`, `inlinesvg`, `smil`, and `svgclippaths`
* Misc bugfixes as well as compatibility fixes for Firefox 4 and IE9

### v0.9.1

* First public release
