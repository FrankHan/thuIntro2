/**
 * @type {boolean}
 */
Window.prototype.navigator.standalone;
